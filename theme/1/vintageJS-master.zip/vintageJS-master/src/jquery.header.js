;(function($, window, document, undefined) {
  $.fn.vintage = function(options, effect) {
